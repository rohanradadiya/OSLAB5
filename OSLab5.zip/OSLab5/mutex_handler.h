#ifndef MUTEX_HANDLER_H
#define MUTEX_HANDLER_H

#include <pthread.h>

//declares the mutex handling functions
// You can declare any mutex-related functions or structures here

//MUTEX_HANDLER_H
#endif 

