#include "banker.h" // Include the header file where necessary declarations are stored
#include <stdio.h>

// Function to check if the system is in a safe state
bool isSafe() {
    bool completion[totalNumberOfCustomers]; // Array to track if each customer's processes are completed
    bool alert = true; // Flag to indicate if the system is not safe
    int count = 0; // Counter to track completed processes
    int custCounter = 1; // Counter for customers
    int workNeeded[totalNumberOfResources]; // Array to store the work needed for each resource
    bool processPossibility = true; // Flag to check if a process is possible
    
    // Initialize the work needed array with available resources
    for (int i = 0; i < totalNumberOfResources; i++)
        workNeeded[i] = available[i];

    //updates the work needed array with the allocation of resources for a specific customer
    for (int k = 0; k < totalNumberOfResources; k++)
        workNeeded[k] += allocationOfResources[custCounter][k];
    
    //initializes the completion array to false for all customers
    for (int i = 0; i < totalNumberOfCustomers; i++)
        completion[i] = false;

    //loops until all of the processes are completed
    while (count < totalNumberOfCustomers) {
        // Check if the current customer's processes are completed
        if (completion[custCounter] == false) {
            // Check if the process can be executed with the available resources
            for (int j = 0; j < totalNumberOfResources; j++)
                if (need[custCounter][j] > workNeeded[j])
                    processPossibility = false;

            // If the process is possible, update the work needed array and mark the process as completed
            if (processPossibility) {
                for (int k = 0; k < totalNumberOfResources; k++)
                    workNeeded[k] += allocationOfResources[custCounter][k];
                completion[custCounter] = true;
                count++;
                custCounter = (custCounter + 1) % totalNumberOfCustomers;
                break;
            }
        }

        // Check if all unfinished processes can be executed safely
        for (int i = 0; i < totalNumberOfCustomers; i++)
            if (completion[i] == false) {
                for (int j = 0; j < totalNumberOfResources; j++)
                    if (workNeeded[j] > need[custCounter][j])
                        alert = false;
                break;
            }

        // If the system is not safe, return false
        if (alert == true)
            return false;
    }

    // If all processes can be executed safely, return true
    return true;
}

// Function to release resources
bool release_resources(int release[], int customerNumber) {
    // Release resources by adding them back to the available pool
    for (int i = 0; i < totalNumberOfResources; i++) {
        available[i] += release[i];
    }
    return true;
}

// Function to request resources
bool resourcesToRequest(int requestMade[], int customerNumber) {
    printf("\nCUSTOMER NUMBER: %d is requesting resources shown in this list: ", customerNumber);
    // Print the resources requested
    for (int i = 0; i < totalNumberOfResources; i++) {
        printf("%d ", requestMade[i]);
    }
    printf("\nThe available resources right now seem to be: ");
    // Print the available resources
    for (int i = 0; i < totalNumberOfResources; i++) {
        printf("%d ", available[i]);
    }
    printf("\n");

    printf("The remaining requirement is shown in this given list: ");
    // Print the remaining requirement
    for (int i = 0; i < totalNumberOfResources; i++) {
        printf("%d ", need[customerNumber][i]);
    }
    printf("\n");

    // Check if the requested resources can be granted
    for (int i = 0; i < totalNumberOfResources; i++) {
        // Check if the requested resources exceed the need
        if (requestMade[i] <= need[customerNumber][i]) {
            // Check if the requested resources exceed the available resources
            if (requestMade[i] > available[i]) {
                printf("The program doesn't seem to be safe with the request made. The requests are more than what is available. \n");
                return false;
            } else {
                // If the system is safe, grant the resources
                if (isSafe()) {
                    printf("The system seems to be safe, and the resources are granted.\n");
                    for (int i = 0; i < totalNumberOfResources; i++) {
                        available[i] -= requestMade[i];
                        allocationOfResources[customerNumber][i] += requestMade[i];
                        need[customerNumber][i] -= requestMade[i];
                    }
                    return true;
                } else {
                    printf("The system doesn't seem to be safe, and the resources cannot be granted right now.\n\n");
                    return false;
                }
            }
        } else if (requestMade[i] > need[customerNumber][i]) {
            printf("The request seems to be more than what is needed. We will have to exit now. \n");
            return false;
        }
    }
}

// Function to release priority resources
void releasePriorityResources(int customerNumber) {
    pthread_mutex_lock(&lock);
    // Lock the mutex to ensure thread safety
    for (int u = 0; u < totalNumberOfResources; u++)
        release_resources(maxAmount[customerNumber], customerNumber);
    pthread_mutex_unlock(&lock);
    // Unlock the mutex after releasing resources
    printf("\nAs of now, thread number %d seems to have finished the required execution \n", customerNumber);
}

// Function to request priority resources
bool requestPriorityResources(int requestMade[], int customerNumber) {
    bool released = false;
    pthread_mutex_lock(&lock);
    released = resourcesToRequest(requestMade, customerNumber);
    pthread_mutex_unlock(&lock);
    return released;
}

