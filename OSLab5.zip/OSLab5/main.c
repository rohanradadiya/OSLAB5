#include <stdio.h> // Include necessary standard input/output header
#include <stdlib.h> // Include necessary standard library header
#include <pthread.h> // Include necessary pthread library header
#include "banker.h" // Include custom header file

#define totalNumberOfCustomers 5 // Define constant for total number of customers
#define totalNumberOfResources 3 // Define constant for total number of resources

// Declare global variables for available resources, maximum amounts, allocations, and need
int available[totalNumberOfResources];
int maxAmount[totalNumberOfCustomers][totalNumberOfResources];
int allocationOfResources[totalNumberOfCustomers][totalNumberOfResources];
int need[totalNumberOfCustomers][totalNumberOfResources];

pthread_mutex_t lock; // Declare mutex lock variable

// Function to simulate resources being acquired by a customer
void* getResources(void *arg) {
    bool processesReleased = false; // Flag to indicate if processes have been released
    int customerNumber = *(int *)arg; // Extract customer number from argument

    // Define requests for resources
    int firstRequest[] = {1, 1, 2};
    int secondRequest[] = {5, 2, 6};
    int thirdRequest[] = {2, 1, 2};

    // Request resources until successful
    while (requestPriorityResources(firstRequest, customerNumber) == false);
    while (requestPriorityResources(secondRequest, customerNumber) == false);
    while (requestPriorityResources(thirdRequest, customerNumber) == false);

    // Release resources after completion
    releasePriorityResources(customerNumber);

    return 0; // Exit thread
}

//represents the main function
int main(int argc, char *argv[]) {
    // Check if correct number of command line arguments are provided
    if (argc != totalNumberOfResources + 1) {
        fprintf(stderr, "PLEASE INPUT AS SHOWN: ./main <'Number of resource 1:'> <'Number of resource 2:'> <'Number of resource 3:'>\n");
        // Exit program with error status
        exit(1); 
    }

    // Check if any command line argument is negative
    for (int i = 1; i < argc; i++)
        if (atoi(argv[i]) < 0) {
            fprintf(stderr, "You have entered a negative value. Please try again. You previously entered:%d\n", atoi(argv[i]));
            // Exit program with error status
            exit(1); 
        }

    //initializes the available resources and other arrays based on command line arguments
    for (int i = 0; i < totalNumberOfResources; i++) {
        available[i] = atoi(argv[i + 1]);

        //initializes the maximum amounts, need, and allocations for each customer
        for (int j = 0; j < totalNumberOfCustomers; j++) {
            maxAmount[j][i] = 10;
            need[j][i] = 10;
            allocationOfResources[j][i] = 0;
        }
    }
    
    pthread_t tid[totalNumberOfCustomers]; // Declare pthread_t array

    int process_num[] = {0, 1, 2, 3, 4}; // Define process numbers
    // Create threads for each customer
    for (int k = 0; k < totalNumberOfCustomers; k++)
        pthread_create(&(tid[k]), NULL, getResources, &process_num[k]);

    // Wait for all threads to finish execution
    for (int i = 0; i < totalNumberOfCustomers; i++)
        pthread_join(tid[i], 0);

    printf("\nThe program has reached the end. Please exit or try again.\n"); // Print message indicating program completion
    printf("\nThank you for your time!\n\n");
    pthread_mutex_destroy(&lock); // Destroy mutex lock

    return 0; // Exit program
}

