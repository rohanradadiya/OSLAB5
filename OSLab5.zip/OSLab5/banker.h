#ifndef BANKER_H
#define BANKER_H

#include <stdbool.h> // Include necessary header for boolean data type
#include <pthread.h> // Include necessary header for pthread library

// Define constants for the total number of customers and resources
#define totalNumberOfCustomers 5
#define totalNumberOfResources 3

// Declare external variables and mutex lock
extern int available[totalNumberOfResources];
extern int maxAmount[totalNumberOfCustomers][totalNumberOfResources];
extern int allocationOfResources[totalNumberOfCustomers][totalNumberOfResources];
extern int need[totalNumberOfCustomers][totalNumberOfResources];
extern pthread_mutex_t lock;

// Declare function prototypes
bool resourcesToRequest(int requestMade[], int customerNumber);
bool resourcesToRelease(int release[], int customerNumber);
bool isSafe();
void releasePriorityResources(int customerNumber);
bool requestPriorityResources(int requestMade[], int customerNumber);

#endif // BANKER_H

